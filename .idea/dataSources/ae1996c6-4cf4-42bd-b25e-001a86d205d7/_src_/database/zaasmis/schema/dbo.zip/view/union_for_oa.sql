CREATE VIEW dbo.union_fro_oa
AS
SELECT     person_type, username, password, name, end_time, dept_id, gender, id_card, picture, email, cellphone
FROM         dbo.doc_for_oa
UNION
SELECT     TOP (100) PERCENT person_type, username, password, name, end_time, dept_id, gender, id_card, picture, EMAIL, cellphone
FROM         dbo.staff_for_OA
UNION
SELECT     TOP (100) PERCENT person_type, username, password, name, end_time, dept_id, gender, id_card, picture, email, cellphone
FROM         dbo.stu_for_oa
UNION
SELECT     TOP (100) PERCENT person_type, username, password, name, end_time, dept_id, gender, id_card, picture, email, cellphone
FROM         dbo.disp_for_oa
UNION
SELECT     TOP (100) PERCENT person_type, username, password, name, end_time, dept_id, gender, id_card, picture, email, cellphone
FROM         dbo.temp_for_oa
